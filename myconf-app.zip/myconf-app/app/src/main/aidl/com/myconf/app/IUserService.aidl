package com.myconf.app;

interface IUserService {
    void destroy() = 16777114;
    void exit() = 1;
    String exec(String cmd) = 2;
    String write(String path, String content) = 3;
}
