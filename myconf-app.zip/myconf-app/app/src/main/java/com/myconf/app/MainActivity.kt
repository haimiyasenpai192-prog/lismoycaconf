package com.myconf.app

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object {
        const val GAME = "com.kurogame.wutheringwaves.global"
        const val DATA = "/sdcard/Android/data/$GAME/files"
        const val DST = "$DATA/UE4Game/Client/Client/Saved/Config/Android"
        const val PSO = "$DATA/VulkanProgramBinaryCache"
        const val BAK = "/sdcard/Download/MyConf_backup"
    }

    private var svc: IUserService? = null
    private var binding = false
    private var tries = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var spinner: Spinner

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
            .daemon(false)
            .processNameSuffix("svc")
            .debuggable(false)
            .version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = IUserService.Stub.asInterface(binder)
            binding = false
            say("Terhubung ke Shizuku. Siap dipakai.")
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null; binding = false }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { connect() }

    private val deadListener = Shizuku.OnBinderDeadListener {
        svc = null
        binding = false
        say("Koneksi Shizuku terputus. Start Shizuku lagi.")
    }

    // Cek ulang tiap 1 detik: binder Shizuku kadang datang terlambat / tidak lewat listener.
    private val poll = object : Runnable {
        override fun run() {
            if (svc != null) return
            if (Shizuku.pingBinder()) {
                connect()
            } else if (tries == 0) {
                say("Menunggu Shizuku... (binder belum diterima)")
            }
            tries++
            if (tries == 15 && svc == null) {
                say(diag())
                say("Binder Shizuku tidak masuk ke app. Coba: Force stop MyConf lalu buka lagi (Shizuku harus sudah status running), atau tekan 'Hubungkan ulang'.")
            }
            if (tries < 15 || (svc == null && Shizuku.pingBinder() && tries < 30)) {
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) bind() else say("Izin Shizuku ditolak.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "MyConf - WuWa Config Installer"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        })

        spinner = Spinner(this)
        val names = assets.list("profiles")?.toList() ?: emptyList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        root.addView(spinner)

        root.addView(button("Hubungkan ulang") { reconnect() })
        root.addView(button("Install profil") { doInstall() })
        root.addView(button("Restore config asli") { doRestore() })
        root.addView(button("Hapus config custom") { doRemove() })
        root.addView(button("Hapus shader cache") { doShader() })
        root.addView(button("Status") { doStatus() })

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
        }
        root.addView(
            ScrollView(this).apply { addView(logView) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        say("Pastikan Shizuku sudah jalan (wireless debugging).")
    }

    override fun onResume() {
        super.onResume()
        if (svc == null) { tries = 0; handler.removeCallbacks(poll); handler.post(poll) }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(poll)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) {}
    }

    // ---------- Shizuku ----------

    private fun diag(): String = try {
        "Diagnosa: ping=" + Shizuku.pingBinder() +
            ", izin=" + (if (Shizuku.pingBinder()) Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED else "?") +
            ", versi API server=" + (if (Shizuku.pingBinder()) Shizuku.getVersion() else "?") +
            ", uid server=" + (if (Shizuku.pingBinder()) Shizuku.getUid() else "?")
    } catch (e: Throwable) { "Diagnosa error: " + e.message }

    private fun connect() {
        if (svc != null || binding) return
        if (!Shizuku.pingBinder()) return
        try {
            if (Shizuku.isPreV11()) {
                say("Versi Shizuku terlalu lama, update dulu.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bind()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                say("Izin ditolak permanen. Buka Shizuku > Kelola aplikasi, aktifkan MyConf.")
            } else {
                Shizuku.requestPermission(1)
            }
        } catch (e: Throwable) {
            say("Gagal connect: " + e.message)
        }
    }

    private fun bind() {
        if (binding || svc != null) return
        binding = true
        try {
            Shizuku.bindUserService(args, conn)
            say("Menghubungkan service Shizuku...")
            handler.postDelayed({
                if (svc == null && binding) {
                    binding = false
                    say("Service tidak merespon. " + diag())
                }
            }, 6000)
        } catch (e: Throwable) {
            binding = false
            say("bindUserService gagal: " + e.message)
        }
    }

    private fun reconnect() {
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        svc = null
        binding = false
        tries = 0
        say("Mencoba hubungkan ulang...")
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    // ---------- UI helper ----------

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun say(t: String) {
        runOnUiThread { logView.append(t + "\n") }
    }

    private fun work(block: (IUserService) -> Unit) {
        val s = svc
        if (s == null) {
            say("Belum terhubung ke Shizuku. " + diag())
            return
        }
        Thread {
            try { block(s) } catch (e: Exception) { say("Error: " + e.message) }
        }.start()
    }

    private fun folderExists(s: IUserService, path: String) =
        s.exec("[ -d '$path' ] && echo yes").contains("yes")

    // ---------- Aksi ----------

    private fun doInstall() {
        val p = spinner.selectedItem?.toString() ?: return
        work { s ->
            if (!folderExists(s, DST)) {
                say("Folder config game belum ada. Buka game sampai menu utama dulu.")
                return@work
            }
            s.exec("am force-stop $GAME")
            if (!folderExists(s, BAK)) {
                s.exec("mkdir -p '$BAK' && cp '$DST'/*.ini '$BAK'/")
                say("Backup config asli disimpan di $BAK")
            }
            val files = assets.list("profiles/$p") ?: emptyArray()
            for (f in files) {
                val text = assets.open("profiles/$p/$f").bufferedReader(Charsets.UTF_8).readText()
                say("$f -> " + s.write("$DST/$f", text))
            }
            say("Selesai. Disarankan hapus shader, lalu buka game.")
        }
    }

    private fun doRestore() = work { s ->
        if (!s.exec("ls '$BAK'/*.ini 2>/dev/null").contains(".ini")) {
            say("Belum ada backup.")
            return@work
        }
        s.exec("am force-stop $GAME")
        s.exec("cp '$BAK'/*.ini '$DST'/")
        say("Config asli dikembalikan.")
    }

    private fun doRemove() = work { s ->
        s.exec("am force-stop $GAME")
        s.exec("rm -f '$DST/Engine.ini' '$DST/DeviceProfiles.ini'")
        say("Config custom dihapus.")
    }

    private fun doShader() = work { s ->
        s.exec("am force-stop $GAME")
        s.exec("rm -rf '$PSO'/*")
        say("Shader cache dihapus. Loading pertama akan lebih lama.")
    }

    private fun doStatus() = work { s ->
        say("Model  : " + s.exec("getprop ro.product.model").trim())
        say("Android: " + s.exec("getprop ro.build.version.release").trim())
        say("Isi folder config:")
        say(s.exec("ls -l '$DST' 2>&1"))
    }
}
