package com.myconf.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.os.IBinder
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import rikka.shizuku.Shizuku

interface Runner {
    fun exec(cmd: String): String
    fun write(path: String, content: String): String
}

class MainActivity : Activity() {

    companion object {
        const val BAK = "/sdcard/Download/MyConf_backup"
    }

    private var game = "com.kurogame.wutheringwaves.global"
    private var detected = false
    private fun dataDir() = "/sdcard/Android/data/$game/files"
    private fun dst() = "${dataDir()}/UE4Game/Client/Client/Saved/Config/Android"
    private fun pso() = "${dataDir()}/VulkanProgramBinaryCache"

    private var svc: Runner? = null
    private var binding = false
    private var tries = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var spinner: Spinner

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
            .daemon(false)
            .processNameSuffix("svc")
            .debuggable(false)
            .version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val stub = IUserService.Stub.asInterface(binder)
            svc = object : Runner {
                override fun exec(cmd: String) = stub.exec(cmd)
                override fun write(path: String, content: String) = stub.write(path, content)
            }
            binding = false
            say("Terhubung ke Shizuku (user service). Siap dipakai.")
            setShizuku("Shizuku: terhubung", true)
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null; binding = false }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { connect() }

    private val deadListener = Shizuku.OnBinderDeadListener {
        svc = null
        binding = false
        say("Koneksi Shizuku terputus. Start Shizuku lagi.")
        setShizuku("Shizuku: terputus", false)
    }

    // Cek ulang tiap 1 detik: binder Shizuku kadang datang terlambat / tidak lewat listener.
    private val poll = object : Runnable {
        override fun run() {
            if (svc != null) return
            if (Shizuku.pingBinder()) {
                connect()
            } else if (tries == 0) {
                say("Menunggu Shizuku... (binder belum diterima)")
            }
            tries++
            if (tries == 15 && svc == null) {
                setShizuku("Shizuku: belum terhubung", false)
                say(diag())
                say("Binder Shizuku tidak masuk ke app. Coba: Force stop MyConf lalu buka lagi (Shizuku harus sudah status running), atau tekan 'Hubungkan ulang'.")
            }
            if (tries < 15 || (svc == null && Shizuku.pingBinder() && tries < 30)) {
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) bind() else say("Izin Shizuku ditolak.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "MyConf"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "WuWa config installer"
            textSize = 14f
            setTextColor(cMuted)
        })

        val statusCard = card()
        shizukuText = TextView(this).apply {
            text = "Shizuku: menghubungkan..."
            textSize = 15f
            setTextColor(cMuted)
        }
        gameText = TextView(this).apply {
            text = "Game: belum dicek"
            textSize = 15f
            setTextColor(cMuted)
        }
        statusCard.addView(shizukuText)
        statusCard.addView(gameText, lp(6))
        root.addView(statusCard, lp(20))

        val profileCard = card()
        profileCard.addView(TextView(this).apply {
            text = "Profil config"
            textSize = 12f
            setTextColor(cMuted)
        })
        spinner = Spinner(this)
        val names = assets.list("profiles")?.toList() ?: emptyList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        profileCard.addView(spinner)
        root.addView(profileCard, lp(12))

        root.addView(
            styledButton("Install config", cAccent, Color.WHITE, null) { doInstall() }.apply {
                minHeight = dp(58)
                textSize = 17f
            }, lp(16)
        )
        root.addView(TextView(this).apply {
            text = "Memasang profil yang dipilih ke game. Config asli di-backup otomatis."
            textSize = 12f
            setTextColor(cMuted)
        }, lp(6))

        root.addView(styledButton("Restore config asli", cCard, Color.WHITE, cStroke) { doRestore() }, lp(20))
        root.addView(styledButton("Hapus config custom", cCard, Color.WHITE, cStroke) { doRemove() }, lp(8))
        root.addView(styledButton("Hapus shader cache", cCard, Color.WHITE, cStroke) { doShader() }, lp(8))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            styledButton("Hubungkan ulang", cCard, Color.WHITE, cStroke) { reconnect() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
        )
        row.addView(
            styledButton("Status", cCard, Color.WHITE, cStroke) { doStatus() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
        )
        root.addView(row, lp(8))

        val logCard = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(this).apply {
                text = "Log"
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(cMuted)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(textButton("Cek log") { doLog() })
        head.addView(textButton("Salin") { copyLog() })
        logCard.addView(head)
        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Color.parseColor("#D1D5DB"))
            setTextIsSelectable(true)
        }
        logCard.addView(logView, lp(8))
        root.addView(logCard, lp(16))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(root)
        })

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        say("Pastikan Shizuku sudah jalan (wireless debugging).")
    }

    override fun onResume() {
        super.onResume()
        if (svc == null) { tries = 0; handler.removeCallbacks(poll); handler.post(poll) }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(poll)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) {}
    }

    // ---------- Shizuku ----------

    private fun diag(): String = try {
        "Diagnosa: ping=" + Shizuku.pingBinder() +
            ", izin=" + (if (Shizuku.pingBinder()) Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED else "?") +
            ", versi API server=" + (if (Shizuku.pingBinder()) Shizuku.getVersion() else "?") +
            ", uid server=" + (if (Shizuku.pingBinder()) Shizuku.getUid() else "?")
    } catch (e: Throwable) { "Diagnosa error: " + e.message }

    private fun connect() {
        if (svc != null || binding) return
        if (!Shizuku.pingBinder()) return
        try {
            if (Shizuku.isPreV11()) {
                say("Versi Shizuku terlalu lama, update dulu.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bind()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                say("Izin ditolak permanen. Buka Shizuku > Kelola aplikasi, aktifkan MyConf.")
            } else {
                Shizuku.requestPermission(1)
            }
        } catch (e: Throwable) {
            say("Gagal connect: " + e.message)
        }
    }

    private fun bind() {
        if (binding || svc != null) return
        binding = true
        try {
            Shizuku.bindUserService(args, conn)
            say("Menghubungkan service Shizuku...")
            handler.postDelayed({
                if (svc == null && binding) {
                    binding = false
                    say("User service tidak merespon. Pindah ke mode langsung...")
                    useDirectMode()
                }
            }, 6000)
        } catch (e: Throwable) {
            binding = false
            say("bindUserService gagal: " + e.message)
        }
    }

    // Cadangan: jalankan perintah langsung lewat Shizuku.newProcess (tanpa user service).
    private fun directRunner() = object : Runner {
        override fun exec(cmd: String): String {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = try {
                m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            } catch (e: java.lang.reflect.InvocationTargetException) {
                throw (e.targetException ?: e)
            }
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            return out + err
        }

        override fun write(path: String, content: String): String {
            val b64 = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val r = exec("mkdir -p \"$(dirname '$path')\" && echo '$b64' | base64 -d > '$path' && echo ok")
            return if (r.trim().endsWith("ok")) "ok" else "ERR: $r"
        }
    }

    private fun useDirectMode() {
        Thread {
            try {
                val r = directRunner()
                val id = r.exec("id").trim()
                svc = r
                say("Mode langsung aktif. Siap dipakai. ($id)")
                setShizuku("Shizuku: terhubung (mode langsung)", true)
            } catch (e: Throwable) {
                say("Mode langsung juga gagal: " + e.javaClass.simpleName + ": " + e.message)
                setShizuku("Shizuku: gagal terhubung", false)
            }
        }.start()
    }

    private fun reconnect() {
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        svc = null
        binding = false
        detected = false
        tries = 0
        setShizuku("Shizuku: menghubungkan...", null)
        say("Mencoba hubungkan ulang...")
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    // ---------- UI helper ----------

    private val cBg = Color.parseColor("#0B0B10")
    private val cCard = Color.parseColor("#17171F")
    private val cStroke = Color.parseColor("#2A2A36")
    private val cAccent = Color.parseColor("#7C5CFF")
    private val cMuted = Color.parseColor("#9CA3AF")
    private val cOk = Color.parseColor("#4ADE80")
    private val cBad = Color.parseColor("#F87171")

    private lateinit var shizukuText: TextView
    private lateinit var gameText: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int?) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cCard, 16, cStroke)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun styledButton(label: String, fill: Int, textColor: Int, stroke: Int?, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            background = rounded(fill, 14, stroke)
            stateListAnimator = null
            minHeight = dp(50)
            setOnClickListener { onClick() }
        }

    private fun textButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(cAccent)
        setBackgroundColor(Color.TRANSPARENT)
        stateListAnimator = null
        minWidth = 0
        minHeight = dp(36)
        setOnClickListener { onClick() }
    }

    private fun setShizuku(t: String, ok: Boolean?) = runOnUiThread {
        shizukuText.text = t
        shizukuText.setTextColor(when (ok) { true -> cOk; false -> cBad; null -> cMuted })
    }

    private fun setGame(t: String, ok: Boolean?) = runOnUiThread {
        gameText.text = t
        gameText.setTextColor(when (ok) { true -> cOk; false -> cBad; null -> cMuted })
    }


    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun say(t: String) {
        runOnUiThread { logView.append(t + "\n") }
    }

    private fun work(block: (Runner) -> Unit) {
        val s = svc
        if (s == null) {
            say("Belum terhubung ke Shizuku. " + diag())
            return
        }
        Thread {
            try { detectGame(s); block(s) } catch (e: Exception) { say("Error: " + e.message) }
        }.start()
    }

    private fun detectGame(s: Runner) {
        if (detected) return
        detected = true
        val dirs = s.exec("ls -d /sdcard/Android/data/*/files/UE4Game/Client/Client/Saved/Config/Android 2>/dev/null")
            .lines().map { it.trim() }.filter { it.isNotEmpty() }
        val kuro = { t: String -> t.contains("kurogame", true) || t.contains("wutheringwaves", true) || t.contains("mingchao", true) }
        val fromDir = dirs.firstOrNull(kuro)?.removePrefix("/sdcard/Android/data/")?.substringBefore("/")
        val fromPm = s.exec("pm list packages 2>/dev/null | grep -iE 'kurogame|wutheringwaves|mingchao'")
            .lines().map { it.trim().removePrefix("package:") }.firstOrNull { it.isNotEmpty() }
        val found = fromDir ?: fromPm
        if (found != null) {
            game = found
            say("Game terdeteksi: $game" + if (fromDir == null) " (folder config belum ada)" else "")
            setGame("Game: $game" + if (fromDir == null) " (buka game dulu)" else "", fromDir != null)
        } else {
            say("Game WuWa tidak terdeteksi di HP. Pakai paket default: $game")
            setGame("Game: tidak terdeteksi", false)
        }
    }

    private fun folderExists(s: Runner, path: String) =
        s.exec("[ -d '$path' ] && echo yes").contains("yes")

    // ---------- Aksi ----------

    private fun doInstall() {
        val p = spinner.selectedItem?.toString() ?: return
        work { s ->
            if (!folderExists(s, dst())) {
                say("Folder config game belum ada: ${dst()}")
                say("Isi folder data game: " + s.exec("ls '${dataDir()}' 2>&1").trim())
                say("Buka game sampai menu utama dulu, lalu coba lagi.")
                return@work
            }
            s.exec("am force-stop $game")
            if (!folderExists(s, BAK)) {
                s.exec("mkdir -p '$BAK' && cp '${dst()}'/*.ini '$BAK'/")
                say("Backup config asli disimpan di $BAK")
            }
            val files = assets.list("profiles/$p") ?: emptyArray()
            for (f in files) {
                val text = assets.open("profiles/$p/$f").bufferedReader(Charsets.UTF_8).readText()
                val r = s.write("${dst()}/$f", text)
                val size = s.exec("wc -c < '${dst()}/$f' 2>&1").trim()
                val expect = text.toByteArray(Charsets.UTF_8).size
                say("$f -> $r (di HP: $size byte, seharusnya: $expect byte)" + if (size == expect.toString()) " OK" else " TIDAK COCOK")
            }
            say("Isi folder config sekarang:\n" + s.exec("ls -l '${dst()}' 2>&1").trim())
            say("Selesai. Disarankan hapus shader, lalu buka game.")
        }
    }

    private fun doRestore() = work { s ->
        if (!s.exec("ls '$BAK'/*.ini 2>/dev/null").contains(".ini")) {
            say("Belum ada backup.")
            return@work
        }
        s.exec("am force-stop $game")
        s.exec("cp '$BAK'/*.ini '${dst()}'/")
        say("Config asli dikembalikan.")
    }

    private fun doRemove() = work { s ->
        s.exec("am force-stop $game")
        s.exec("rm -f '${dst()}/Engine.ini' '${dst()}/DeviceProfiles.ini'")
        say("Config custom dihapus.")
    }

    private fun doShader() = work { s ->
        s.exec("am force-stop $game")
        s.exec("rm -rf '${pso()}'/*")
        say("Shader cache dihapus. Loading pertama akan lebih lama.")
    }

    private fun ownLog(): String {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "300"))
        return p.inputStream.bufferedReader().readLines()
            .filter { it.contains("myconf", true) || it.contains("shizuku", true) || it.contains("AndroidRuntime") }
            .takeLast(40).joinToString("\n")
    }

    private fun doLog() {
        val cmd = "logcat -d -t 1000 2>&1 | grep -iE 'shizuku|AndroidRuntime|UserService|app_process|FATAL' | tail -n 40"
        say("== Log Shizuku/MyConf ==")
        Thread {
            try {
                val runner = svc ?: if (Shizuku.pingBinder()) directRunner() else null
                val out = if (runner != null) runner.exec(cmd) else ownLog()
                say(if (out.isBlank()) "(log kosong)" else out.trim())
            } catch (e: Throwable) {
                say("Gagal baca log lewat Shizuku: " + e.message)
                try { say(ownLog().ifBlank { "(log app kosong)" }) } catch (_: Throwable) {}
            }
        }.start()
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("MyConf log", logView.text))
        say("Log disalin ke clipboard.")
    }

    private fun doStatus() = work { s ->
        say("Game   : $game")
        say("Model  : " + s.exec("getprop ro.product.model").trim())
        say("Android: " + s.exec("getprop ro.build.version.release").trim())
        say("Isi folder config:")
        say(s.exec("ls -l '${dst()}' 2>&1"))
    }
}
