package com.myconf.app

import java.io.File
import kotlin.system.exitProcess

// Kelas ini jalan di proses terpisah dengan izin shell (ADB) lewat Shizuku.
class UserService : IUserService.Stub() {

    override fun destroy() { exitProcess(0) }

    override fun exit() { destroy() }

    override fun exec(cmd: String): String {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out + err
    }

    override fun write(path: String, content: String): String {
        return try {
            val f = File(path)
            f.parentFile?.mkdirs()
            f.writeText(content, Charsets.UTF_8)
            "ok"
        } catch (e: Exception) {
            "ERR: " + e.message
        }
    }
}
