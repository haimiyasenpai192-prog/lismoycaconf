# MyConf

Aplikasi pemasang config Wuthering Waves (Android) lewat Shizuku.

## Build lewat GitHub
1. Upload semua isi folder ini ke repo (branch `main`, folder `.github` harus ada di root repo).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Setelah hijau, download artifact **MyConf-debug-apk**, ekstrak, lalu install `app-debug.apk`.

## Pakai
1. Install Shizuku, start lewat wireless debugging.
2. Buka MyConf, izinkan akses Shizuku.
3. Pilih profil, tekan **Install profil**, lalu **Hapus shader cache**.

## Tambah profil
Buat folder baru di `app/src/main/assets/profiles/<nama>/` berisi `Engine.ini` dan/atau `DeviceProfiles.ini`, lalu build ulang.
